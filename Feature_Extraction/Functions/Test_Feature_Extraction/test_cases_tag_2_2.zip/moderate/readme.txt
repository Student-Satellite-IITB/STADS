the input.ods and input.csv files differ. use input.csv for testing
use input.ods to refer the expected tag values of each region

all inputs are 10x10 arrays which gets modified into [1,2-11]x[1,2-11] after the addition of the layer of zeroes
all output part 1s have a 40x5 array along the lines of the readme uploaded on git
all output part 2s have a 1x2 array