the input.ods and input.csv are different files.
input.csv is the first 10 rows of the input.ods file.
the subsequent 90 rows in input.ods is a repetition of the first 10 in the same order

input reference.ods is the way the input file is expected to be tagged. do take a look, if the output fails

input.ods has 250 tags and 50 final tags