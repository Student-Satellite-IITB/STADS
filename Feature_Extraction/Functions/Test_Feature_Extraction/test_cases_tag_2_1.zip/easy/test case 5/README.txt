Centroid 4.5,4.5
num_tags 1