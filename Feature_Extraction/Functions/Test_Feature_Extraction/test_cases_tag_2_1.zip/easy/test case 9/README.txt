Centroid 6,5
num_tags 2