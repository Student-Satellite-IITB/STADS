All inputs are 10 x 10 matrices in .csv format
All output part 1 have 5 columns and 50 rows in .csv format 
All output part 2 have 2 columns and 1 row in .csv format

tag numbers start with 1
final tag numbers start with 1
input array is [1-10] x [1-10] which becomes [1-11] x [1-11] after modification in code

centroid coordinates are given for the 'reduced' 10 x 10 array