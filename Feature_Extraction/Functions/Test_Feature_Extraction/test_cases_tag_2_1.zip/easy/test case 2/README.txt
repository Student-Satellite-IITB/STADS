Centroid (3,3) (7,6.33)
num_tags 2