Centroid 5.5,5.5
num_tags 1