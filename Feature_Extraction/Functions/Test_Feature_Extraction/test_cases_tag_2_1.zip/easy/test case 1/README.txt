Centroid 3,3
num_tags 1