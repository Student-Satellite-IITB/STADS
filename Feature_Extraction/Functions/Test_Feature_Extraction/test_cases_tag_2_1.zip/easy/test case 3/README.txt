All 0's
Centroid Nil
num_tags Nil